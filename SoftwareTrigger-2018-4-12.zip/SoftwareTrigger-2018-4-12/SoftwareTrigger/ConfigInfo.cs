﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace SoftwareTrigger
{
    //public class ConfigInfo
    //{
    //    private Int32 _StartTest0 = 120;
    //    [CategoryAttribute("二值化上限值"), DescriptionAttribute("设置上限值")]
    //    public Int32 灰度值
    //    {
    //        get { return _StartTest0; }
    //        set { _StartTest0 = value; }
    //    }

    //    private Int32 _StartTest1 = 800;
    //    [CategoryAttribute("缺陷区域面积最小值"), DescriptionAttribute("设置缺陷最小面积")]
    //    public Int32 面积
    //    {
    //        get { return _StartTest1; }
    //        set { _StartTest1 = value; }
    //    }

    //    private Int32 _StartTest2 = 60;
    //    [CategoryAttribute("滤波尺寸"), DescriptionAttribute("设置滤波尺寸")]

    //    public Int32 滤波尺寸
    //    {
    //        get { return _StartTest2; }
    //        set { _StartTest2 = value; }
    //    }

    //    private Int32 _StartTest3 = 4;
    //    [CategoryAttribute("动态二值化阈值"), DescriptionAttribute("设置动态二值化阈值")]
    //    public Int32 动态二值化阈值
    //    {
    //        get { return _StartTest3; }
    //        set { _StartTest3 = value; }
    //    }
    //}
}
